from typing import Tuple
from pyproj import Transformer

def lonlat_to_epsg3857(lon: float, lat: float) -> Tuple[float, float]:
    t = Transformer.from_crs(4326, 3857, always_xy=True)
    return t.transform(lon, lat)
