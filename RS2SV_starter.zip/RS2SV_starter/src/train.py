from omegaconf import OmegaConf
from hydra import initialize, compose

def main():
    with initialize(version_base=None, config_path="../configs"):
        cfg = compose(config_name="default")
    print(OmegaConf.to_yaml(cfg))
    # TODO: wire up DataModule, Model, Trainer

if __name__ == "__main__":
    main()
