from typing import Optional
from torch.utils.data import DataLoader, Dataset

class DummyPairDataset(Dataset):
    def __len__(self):
        return 10
    def __getitem__(self, idx):
        # overhead, streetview, metadata
        return {"overhead": idx, "street": idx, "meta": {"idx": idx}}

def make_dataloaders(batch_size: int = 2):
    ds = DummyPairDataset()
    return DataLoader(ds, batch_size=batch_size)

