def test_imports():
    import src, src.data, src.models, src.utils  # noqa
